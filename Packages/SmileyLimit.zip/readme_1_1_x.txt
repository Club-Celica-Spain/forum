SmileyLimit
by Snork13
snork13@simplemachines.org

SmileyLimit
version: 1.1

Tired of members posting too many smileys? 

SmileyLimit was packaged up from the tips and tricks board, see topic id#17213.0 by Owdy & [Unknown].
I added an admin setting to control the number you wish to have. 
Access via the admin panel->Smileys and Message Icons.

Files edited:

$sourcedir/Post.php
$sourcedir/ManageSmileys.php
$themedir/ManageSmileys.template.php
$themedir/languages/Post.english.php
$themedir/languages/ModSettings.english.php
$themedir/languages/ManageSmileys.english.php

database changes via:

add_settings.php

