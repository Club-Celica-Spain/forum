[center][hr]
[color=red][size=16pt][b]AUTO EMAIL INACTIVE ORDINARY USERS v1.7[/b][/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?action=profile;u=63186][b]Originally by Karl Benson[/b][/url]
[url=http://custom.simplemachines.org/mods/index.php?action=profile;u=117131][b]Taken over by Ryan Wagoner[/b][/url]
[hr][/center]

[color=blue][size=12pt][u][b]Compatibility[/b][/u][/size][/color]
For SMF 1.1.x and SMF 2.0 Beta 3 / 3.1

[color=blue][size=12pt][u][b]Introduction[/b][/u][/size][/color]
Automatically email inactive users to try to remind/tempt them to come back.

[color=blue][size=12pt][u][b]~ Warning ~[/b][/u][/size][/color]
Remember to Backup BOTH your DATABASE (structure & data) and your FILES [u]BEFORE[/u] installing this mod.
Due to the way this mod works, it MAY affect performance/resource usage/mail servers.
Although currently its working perfectly fine on some very HUGE forums (with 50,000+ members).

[color=blue][size=12pt][u][b]How The Mod Works[/b][/u][/size][/color]
=> User has not visited for 21 days or more
==> An Initial Email Sent
===> Another 21 days passes and user still has not visited
====> A Final Email Sent
=====> Another 21 days passes and user still has not visited
======> (Optional for SMF 1.1.x) Delete User Account (With a Threshold setting eg Delete users only if they have made less than 10 posts)

[color=blue][size=12pt][u][b]Features[/b][/u][/size][/color]
o Adds a new section in the admin area 
- Admin > Features & Options > AEIOU (SMF 1.1.x)
- Admin > Modifications > Email Inactive (SMF 2.0 Beta 3 / 3.1)
- Note: The mod is disabled straight after installation to enable you to customize the emails and settings.
o Includes Settings
- Customize Initial Email Subject (text-only) [with replaced variables]
- Customize Initial Email Message (text-only) [with replaced variables]
- Customize Final Email Subject (text-only) [with replaced variables]
- Customize Final Email Subject (text-only) [with replaced variables]
- Enable/Disable Deleting of Users (Only SMF 1.1.x)
 > Set a Post Threshold
o Other Settings (But NOT recommended to alter) (Only SMF 1.1.x)
- Chunksize
- Max Emails To Send Per Hour
- Max Emails To Send Per Day
o Panel showing stats and status of the mod
o Panel showing last 10 inactive users emailed
o Tries to prevent overloading your mail server
- Uses hourly / daily mail limits (SMF 1.1.x)
- Uses the mail queue if enabled (SMF 2.0 Beta 3 / 3.1)
o Anti-spam prevention
- Sending times/periods are hard-coded and cannot be changed
- Limits the no. of emails to be sent out by this mod to TWO.
- User who return after receiving an email have the email process reset (back to 0 email sent)
o Supports Languages
- Note: I welcome translations for other languages. Please post the translated language strings in the Support Topic.
- English/English-utf8
- English_British/English_British-utf8 (Only SMF 1.1.x)

[color=blue][size=12pt][u][b]Installation[/b][/u][/size][/color]
Any previous versions of this mod MUST be uninstalled BEFORE installing this version.
(Note: Existing database settings will remain. However existing custom emails created in pre-v1.3 will be reset)

Install the mod via the Package Manager to install on ALL themes.
As there are no theme edits for this mod. It only affects Source Files.

If your using a different language than those supported by this mod (listed above), then you will need to add (and translate as necessary) the 

language strings to your Modifications.{language}.php and/or Modifications.{language}-utf8.php for each theme (The language folder can be found at Themes/{themename}/languages/).

[color=blue][size=12pt][u][b]Common Questions[/b][/u][/size][/color]
o Can the periods before and between sending emails be changed?
- No. The periods are hardcoded.  However the periods are ONLY minimums. On large forums, it could be longer.
o Whats the minimum period between becoming inactive and user deletion?
- 63 days minimum
- Minimum 21 days to become inactive for sending the initial email
- Minimum 21 days before sending the final email
- Minimum 21 days before deleted user (Optionally with SMF 1.1.x)
 > Note however, it may take longer in each stage depending on the no. of users to email/delete.
o Emails are not being received. Why is it not working?
- A 5 point checklist
 1) Get users to check their spam/junk folder. The users mail provider may believe it to be spam.
   > If so, this is not a bug with this mod.  It could be being labelled as spam for several reasons.
 2) Even though the mod takes care not to overload your mailserver, it is possible it may have been by SMFs other emailing functions.
   > Email yourself using SMF, if you don't receive the email then it is likely your mailserver is overloaded or not functioning
   > Most hosts have limits (not always publicised) on the no. of emails per hour/day - Contact your host and find out what they are.
   > Sending Newsletters and announcing topics are common ways to overload your mail server.
 3) Is the Last 10 Inactive Users Emailed showing recent emails?
   > If it is, then as far as the mod is concerned its working properly.
 4) Are there any errors related to it in your error log?
 5) Alternatively I am willing to consider it could be a bug. See Support.

[color=blue][size=12pt][u][b]Support[/b][/u][/size][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

[color=blue][size=12pt][u][b]Changelog[/b][/u][/size][/color]
[b]1.7 - 8th May 2008[/b]
o Added support for SMF 2.0 Beta 3 / 3.1
[b]1.6 - 1st May 2008[/b]
o Fixed hourly/daily stats not resetting (when down to the last few people)
o Few comment changes
o Few re-ordering of code changes
o Moved call of subs-post.php to only when needed
o Checked works for SMF 1.1.5
[b]1.5 - 28th April 2008[/b]
o Fixed issues where the mod stops (removed lockkey)
o Fixed so admins don't get emailed (even though they wouldn't get deleted)
o Fixed differences between admin vs actual query (takes dateRegistered into account)
o Fixed undefined aeiou_stop
[b]1.4 - 4th March 2008[/b]
o Fixed times to take users times
o Fixed emails to strip_tags as html would break sending email
o Altered install.xml to reduce conflict with other mods
[b]1.3 - 3rd March 2008[/b]
o Removed - all non-english language strings (as most the strings have changed)
o Changed the no. of emails sent from 3 to 2 and the dates
o Fixed so doesn't set to max sent, instead uses a different variable
o Added Stats/Status
o Added Last 10 Users emailed
o Added ability to edit BOTH emails
o Added re-activation - so if stopped and admin views aeiou page and theres emails, restart
o Fixed email replacement variables to use preg (so can use mixed case)
o Changed install.php to delete old email variables
o Changed install.php to support manual install using ssi
[b]1.2 - 16th January 2008[/b]
o Fixed so don't email members awaiting account deletion by admin
o Fixed not resetting amount sent per hour/day at same time
o Improved checks for reaching limit
[b]1.1 - 13th January 2008[/b]
o Fixed lost password link (action=reminder) (Thanks HugoDiaz)
o Added check to only email activated users
o Added check so don't email banned users (by username only)
o Altered order of to whom it send emails.
o Fixed default message/subject on install (to use current language)
[b]1.0 - 7th December 2007[/b]
o Initial release