<?php
// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
        include_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
        die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

// Upgrade the database if necessary
$request = db_query("SHOW COLUMNS FROM {$db_prefix}members", __FILE__, __LINE__);
while ($row = mysql_fetch_row($request))
	$cols[] = $row[0];
mysql_free_result($request);

if (!in_array("aeiou_email", $cols))
	db_query("
		ALTER IGNORE TABLE {$db_prefix}members
		ADD aeiou_email int(10) NOT NULL default '0'
		AFTER location
		", __FILE__, __LINE__);

if (!in_array("aeiou_count", $cols))
	db_query("
		ALTER IGNORE TABLE {$db_prefix}members
		ADD aeiou_count int(10) NOT NULL default '0'
		AFTER location
		", __FILE__, __LINE__);

// Define each setting to be added
$newSetting['aeiou_enable'] = 0 ;			// Enable mod (disabled by default so you can customize)
$newSetting['aeiou_locktimestamp'] = 0 ;	// Timestamp lock

$newSetting['aeiou_hour_max'] = 50 ;		// Max emails per hour (to keep registrations, notifications, emails going through)
											// based on a server limit of 100 per hour.
$newSetting['aeiou_day_max'] = 500 ;		// Max emails sent in an day at which to disable this mod (to keep registrations, 
											// notifications, emails going through), based on a server limit of 1000 per day
$newSetting['aeiou_hour_sent'] = 0 ;		// Sent this hour (all emails)
$newSetting['aeiou_day_sent'] = 0 ;			// Sent this day (all emails)

$newSetting['aeiou_chunksize'] = 4 ;		// The no. of emails to send at a time (reduce to increase performance)
$newSetting['aeiou_stop'] = 0 ;				// Set to 1 to stop it sending emails until tomorrow (but it still checks for users 
											// to delete, and returning users)

$newSetting['aeiou_delete'] = 0 ;			// (Optional, delete inactive users after 30 days after the 3rd email was sent)
$newSetting['aeiou_underposts'] = 0 ;		// (Optional, choose to delete only those under a post count threshold)

$newSetting['aeiou_initial_subject'] = '';	// To store a custom initial subject message for the email, if blank revert to use 
											// default txt string
$newSetting['aeiou_initial_message'] = '';	// To store a custom initial message, if blank revert to use default txt string
$newSetting['aeiou_final_subject'] = '';	// To store a custom final subject message for the email, if blank revert to use
											// default txt string
$newSetting['aeiou_final_message'] = '';	// To store a custom final message, if blank revert to use default txt string

// Cycle through array adding each new setting - if already exists, ignore
foreach ($newSetting as $key => $value)
	db_query("
		INSERT IGNORE INTO {$db_prefix}settings (`variable`, `value`)
		VALUES ('$key', '$value')", __FILE__, __LINE__);

// Delete settings used by pre 1.4 versions
$delSetting[] = 'aeiou_message';
$delSetting[] = 'aeiou_subject';
$delSetting[] = 'aeiou_lockkey';

// Cycle through array deleting each setting
db_query("
	DELETE FROM {$db_prefix}settings
	WHERE variable = '".implode("' OR variable = '", $delSetting)."'
	", __FILE__, __LINE__);

// If we're using SSI, tell them we're done
if(SMF == 'SSI')
	echo 'Database changes for the AEIOU mod are complete!';

?>
