<?php
// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
        include_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
		die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

// Delete the columns from the database
db_extend('packages');

$smcFunc['db_remove_column']('members', 'aeiou_email');
$smcFunc['db_remove_column']('members', 'aeiou_count');

// Define each setting to be deleted
$delSetting[] = 'aeiou_initial_subject';
$delSetting[] = 'aeiou_initial_message';
$delSetting[] = 'aeiou_final_subject';
$delSetting[] = 'aeiou_final_message';

// Cycle through array deleting each setting
$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}settings
	WHERE variable IN ({array_string:variable})',
	array(
		'variable' => $delSetting
	)
);

// Remove the scheduled task setting
$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}scheduled_tasks 
	WHERE task = {string:task}',
	array(
		'task' => 'email_inactive'
	)
);

// If we're using SSI, tell them we're done
if(SMF == 'SSI')
	echo 'All settings/columns in the database related to the AEIOU mod have been removed!';

?>
