<?php
// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
        include_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
        die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

// Remove the scheduled task setting
$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}scheduled_tasks 
	WHERE task = {string:task}',
	array(
		'task' => 'email_inactive'
	)
);

// If we're using SSI, tell them we're done
if(SMF == 'SSI')
	echo 'Scheduled task for the AEIOU mod has been removed!';

?>
