<?php
// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
        include_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
		die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

// Upgrade the database if necessary
$request = db_query("SHOW COLUMNS FROM {$db_prefix}members", __FILE__, __LINE__);
while ($row = mysql_fetch_row($request))
	$cols[] = $row[0];
mysql_free_result($request);

if (in_array("aeiou_email", $cols))
	db_query("
		ALTER IGNORE TABLE {$db_prefix}members
		DROP aeiou_email", __FILE__, __LINE__);

if (in_array("aeiou_count", $cols))
	db_query("
		ALTER IGNORE TABLE {$db_prefix}members
		DROP aeiou_count", __FILE__, __LINE__);

// Define each setting to be deleted
$delSetting[] = 'aeiou_enable';
$delSetting[] = 'aeiou_locktimestamp';
$delSetting[] = 'aeiou_hour_max';
$delSetting[] = 'aeiou_day_max';
$delSetting[] = 'aeiou_hour_sent';
$delSetting[] = 'aeiou_day_sent';
$delSetting[] = 'aeiou_chunksize';
$delSetting[] = 'aeiou_delete';
$delSetting[] = 'aeiou_underposts';
$delSetting[] = 'aeiou_initial_subject';
$delSetting[] = 'aeiou_initial_message';
$delSetting[] = 'aeiou_final_subject';
$delSetting[] = 'aeiou_final_message';
$delSetting[] = 'aeiou_stop';
// Old v1.2 settings
$delSetting[] = 'aeiou_subject';
$delSetting[] = 'aeiou_message';
// Old v1.4 settings
$delSetting[] = 'aeiou_lockkey';

// Cycle through array deleting each setting
db_query("
	DELETE FROM {$db_prefix}settings
	WHERE variable = '".implode("' OR variable = '", $delSetting)."'
	", __FILE__, __LINE__);

// If we're using SSI, tell them we're done
if(SMF == 'SSI')
	echo 'All settings/columns in the database related to the AEIOU mod have been removed!';

?>
