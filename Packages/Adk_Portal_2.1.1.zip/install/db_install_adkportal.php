<?php
/********************************************************
* Adk Portal                   
* Version: 2.0
* Official support: http://www.smfpersonal.net           
* Founder & Developer: Lucas-ruroken
* Project Manager: ^Heracles^ - Enik
* 2009-2011
* Smf Personal - Home of adkportal
/**********************************************************/

$direct_install = false;

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk portal wasn\'t able to conect to smf');

//CreateTables
$tables = array();

//Anothers $smcFunc;
db_extend('packages');

global $smcFunc;
	
$tables = array(
	//SMF_adk_settings
	'adk_settings' => array(
		'table_name' => '{db_prefix}adk_settings',
		'columns' => array(
			array(
				'name' => 'variable',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'value',
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('variable'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_shoutbox
	'adk_shoutbox' => array(
		'table_name' => '{db_prefix}adk_shoutbox',
		'columns' => array(
			array(
				'name' => 'id',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'date',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'user',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'message',
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_news
	'adk_news' => array(
		'table_name' => '{db_prefix}adk_news',
		'columns' => array(
			array(
				'name' => 'id',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'titlepage',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'new',
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'autor',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'time',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_icons
	'adk_icons' => array(
		'table_name' => '{db_prefix}adk_icons',
		'columns' => array(
			array(
				'name' => 'id_icon',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'icon',
				'type' => 'varchar',
				'null' => false,
				'size' => 255,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id_icon'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_advanced_images
	'adk_advanced_images' => array(
		'table_name' => '{db_prefix}adk_advanced_images',
		'columns' => array(
			array(
				'name' => 'id',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'image',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'url',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_down_permissions
	'adk_down_permissions' => array(
		'table_name' => '{db_prefix}adk_down_permissions',
		'columns' => array(
			array(
				'name' => 'id_group',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
				'default' => '0',
			),
			array(
				'name' => 'id_cat',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
				'default' => '0',
			),
			array(
				'name' => 'view',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
				'default' => '0',
			),
			array(
				'name' => 'addfile',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
				'default' => '0',
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id_group'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_down_attachs
	'adk_down_attachs' => array(
		'table_name' => '{db_prefix}adk_down_attachs',
		'columns' => array(
			array(
				'name' => 'id_attach',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'id_file',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'filename',
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'filesize',
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'orginalfilename',
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id_attach'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_blocks
	'adk_blocks' => array(
		'table_name' => '{db_prefix}adk_blocks',
		'columns' => array(
			array(
				'name' => 'id',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'name',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'echo',
				'auto' => false,
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'activate',
				'auto' => false,
				'type' => 'int',
				'size' => 3,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'columna',
				'auto' => false,
				'type' => 'int',
				'size' => 3,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'orden',
				'auto' => false,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'img',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'type',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'empty_body',
				'auto' => false,
				'type' => 'int',
				'size' => 2,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'empty_title',
				'auto' => false,
				'type' => 'int',
				'size' => 2,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'empty_collapse',
				'auto' => false,
				'type' => 'int',
				'size' => 2,
				'null' => false,
				'unsigned' => true,
			),
			
			array(
				'name' => 'other_style',
				'auto' => false,
				'type' => 'int',
				'size' => 2,
				'null' => false,
				'unsigned' => true,
				'default' => 0,
			),
			array(
				'name' => 'permissions',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
				'default' => '',
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_pages
	'adk_pages' => array(
		'table_name' => '{db_prefix}adk_pages',
		'columns' => array(
			array(
				'name' => 'id_page',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'urltext',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'titlepage',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'body',
				'auto' => false,
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'views',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'grupos_permitidos',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'type',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'winbg',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'cattitlebg',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'enableleft',
				'auto' => false,
				'type' => 'int',
				'size' => 1,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'enableright',
				'auto' => false,
				'type' => 'int',
				'size' => 1,
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id_page'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_down_file
	'adk_down_file' => array(
		'table_name' => '{db_prefix}adk_down_file',
		'columns' => array(
			array(
				'name' => 'id_file',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'id_member',
				'auto' => false,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'date',
				'auto' => false,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'title',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'description',
				'auto' => false,
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'views',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'totaldownloads',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'lastdownload',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'id_cat',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'main_image',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'approved',
				'auto' => false,
				'type' => 'int',
				'size' => 1,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'id_topic',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id_file'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	),
	//SMF_adk_down_cat
	'adk_down_cat' => array(
		'table_name' => '{db_prefix}adk_down_cat',
		'columns' => array(
			array(
				'name' => 'id_cat',
				'auto' => true,
				'type' => 'int',
				'size' => 10,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'title',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'description',
				'auto' => false,
				'type' => 'text',
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'roworder',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'image',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'id_board',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'id_parent',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'total',
				'auto' => false,
				'type' => 'int',
				'size' => 20,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'locktopic',
				'auto' => false,
				'type' => 'int',
				'size' => 1,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'sortby',
				'auto' => false,
				'type' => 'varchar',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
			array(
				'name' => 'orderby',
				'auto' => false,
				'type' => 'int',
				'size' => 255,
				'null' => false,
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'columns' => array('id_cat'),
				'type' => 'primary',
			),
		),
		'if_exists' => 'ignore',
		'error' => 'fatal',
		'parameters' => array(),
	)
);
// Create new tables, if any
foreach ($tables as $table)
	$smcFunc['db_create_table']($table['table_name'], $table['columns'], $table['indexes'], $table['parameters'], $table['if_exists'], $table['error']);

//INSERT IGNORE INTO SMF_adk_settings
$adk_settings = array(
	'adk_enable' => 1,
	'cright' => 1,
	'cleft' => 1,
	'wleft' => '190px',
	//'wcenter' => 60,
	'wright' => '190px',
	'adk_news' => 5,
	'top_poster' => 5,
	'ultimos_mensajes' => 5,
	'auto_news_limit_body' => 500,
	'auto_news_limit_topics' => 5,
	'auto_news_id_boards' => 1,
	'title_in_blocks' => 2,
	'enable_img_blocks' =>  1,
	'enable_pages_seo' => 0,
	'enable_download_seo' => 0,
	'path_seo' => '',
	'change_title' => '',
	'download_enable' => '0',
	'download_max_filesize' => '5000000',
	'download_images_size' => '102400',
	'download_set_files_per_page' => '20',
	'download_enable_sendpmApprove' => '0',
	'download_sendpm_body' => '',
	'download_sendpm_userId' => '',
	'download_max_attach_download' => '1',
	'enable_right_forum' => '0',
	'enable_left_forum' => '0',
	'adv_top_image_limit' => 10,
	'shout_title' => 'Shoutbox',
	'shout_allowed_groups' => 1,
	'shout_allowed_groups_view' => 1,
	'enable_watermark' => 0,
	'enable_related_topics' => 0,
	'enable_top_forum' => '0',
	'enable_bottom_forum' => '0'
);

$replace_array = array();

foreach ($adk_settings as $variable => $value)
	$replace_array[] = array($variable, $value);

//Finally insert
$smcFunc['db_insert']('ignore', '{db_prefix}adk_settings', array('variable' => 'string-255', 'value' => 'string-65534'), $replace_array, array('variable'));			
	
//Alter smf_topics && smf_members
$columns[] = array(
	'table_name' => '{db_prefix}topics',
	'column_info' => array(
		'name' => 'id_new',
		'type' => 'int',
		'size' => 10,
		'default' => 0,
		'auto' => false,
		'unsigned' => false,
	),
	'parameters' => array(),
	'if_exists' => 'ignore',
	'error' => 'fatal',
);

$columns[] = array(
	'table_name' => '{db_prefix}members',
	'column_info' => array(
		'name' => 'adk_notes',
		'type' => 'varchar',
		'size' => 150,
		'default' => '',
		'auto' => false,
		'unsigned' => false,
	),
	'parameters' => array(),
	'if_exists' => 'ignore',
	'error' => 'fatal',
);

//Finally Create Column
foreach($columns AS $add)
	$smcFunc['db_add_column']($add['table_name'], $add['column_info'], $add['parameters'], $add['if_exists'],$add['error']);

//Add new blocks
$adk_blocks = array(
	'main_menu' => array(
		'Main Menu',
		'menuprincipal.php',
		1,
		1,
		1,
		'page.png',
		'include',
	),
	'personal_menu' => array(
		'Personal Menu',
		'menupersonal.php',
		1,
		1,
		2,
		'heart.png',
		'include',
	),
	'users_online' => array(
		'Users online',
		'whois.php',
		1,
		1,
		3,
		'online.png',
		'include',
	),
	'top_posters' => array(
		'Top Posters',
		'topposter10.php',
		1,
		3,
		4,
		'top.png',
		'include',
	),
	'last_topics' => array(
		'Last Topics',
		'ultimosmensajes.php',
		1,
		2,
		1,
		'rosette.png',
		'include',
	),
	'news_adk' => array(
		'News',
		'newsadk.php',
		1,
		2,
		2,
		'feed.png',
		'include',
	),
	'auto_news' => array(
		'Auto News',
		'aportes_automaticos.php',
		0,
		2,
		3,
		'plugin.png',
		'include',
	),
	'stats' => array(
		'Stats',
		'estadisticas.php',
		1,
		3,
		1,
		'stats.png',
		'include',
	),
	'login_logout' => array(
		'Login and Logout',
		'login_logout.php',
		1,
		3,
		2,
		'table_save.png',
		'include',
	),
	'random_image' => array(
		'Random Image',
		'random_image.php',
		0,
		3,
		3,
		'disk.png',
		'include',
	),
	'shoutbox' => array(
		'Shoutbox',
		'adk_shoutbox.php',
		0,
		3,
		4,
		'plugin.png',
		'include',
	),
	'adk_carrousel' => array(
		'Carrousel',
		'adk_carrousel.php',
		0,
		5,
		4,
		'page.png',
		'include',
	),
	'LoadRemembers' => array(
		'Reminders',
		'LoadRemembers.php',
		1,
		3,
		0,
		'disk.png',
		'include',
	),
	'Calendar' => array(
		'Calendar',
		$smcFunc['htmlspecialchars']('<?php ShowMyCalendar(); ?>'),
		0,
		1,
		7,
		'disk.png',
		'php',
	),
	'news_and_news' => array(
		'News and NewsLetter',
		$smcFunc['htmlspecialchars']('<?php adk_bienvenidos(); ?>'),
		1,
		2,
		0,
		'feed2.png',
		'php',
	),
);
	
	
$adk_columns_blocks = array(
	'name' => 'text',
	'echo' => 'text',
	'activate' => 'int',
	'columna' => 'int',
	'orden' => 'int',
	'img' => 'text',
	'type' => 'text',
);
//Finally insert in adk_blocks
$smcFunc['db_insert'](
	//method
	'ignore', 
	//Table name
	'{db_prefix}adk_blocks', 
	//Columns
	$adk_columns_blocks, 
	//The insert
	$adk_blocks, 
	//Ah?
	array('id')
);

// -.-
$adk_icons = array(
	array('disk.png',),
	array('feed.png',),
	array('feed2.png',),
	array('folder.png',),
	array('heart.png',),
	array('help2.png',),
	array('money_dollar.png',),
	array('online.png',),
	array('package.png',),
	array('page.png',),
	array('plugin.png',),
	array('rosette.png',),
	array('sport_raquet.png',),
	array('sport_soccer.png',),
	array('sport_tennis.png',),
	array('stats.png',),
	array('table_save.png',),
	array('tag_purple.png',),
	array('top.png',),
	array('welcome.png',)
);	

//Insert into adk_icons
$smcFunc['db_insert'](
	//method
	'ignore', 
	//Table name
	'{db_prefix}adk_icons', 
	//Columns
	array('icon' => 'text'), 
	//The insert
	$adk_icons, 
	//Ah?
	array('id')
);

//Everybody can view the download section
$permissions = array(
	'adk_downloads_view' => array(-1, 0, 2), // ALL
);
	
addAdkPermissions(&$permissions);

function addAdkPermissions(&$permissions)
{
	global $smcFunc;

	$perm = array();

	foreach ($permissions as $permission => $default)
	{
		$result = $smcFunc['db_query']('', '
			SELECT COUNT(*)
			FROM {db_prefix}permissions
			WHERE permission = {string:permission}',
			array(
				'permission' => $permission
			)
		);

		list ($num) = $smcFunc['db_fetch_row']($result);

		if ($num == 0)
		{
			foreach ($default as $grp)
				$perm[] = array($grp, $permission);
		}
	}

	if (empty($perm))
		return;

	$smcFunc['db_insert']('insert',
		'{db_prefix}permissions',
		array(
			'id_group' => 'int',
			'permission' => 'string'
		),
		$perm,
		array()
	);

}

global $language;

//Possible languages.... yeah we're a site in spanish :)
$espa�ol = array('spanish_es','spanish_latin','spanish_es-utf8','spanish_latin-utf8');

if(in_array($language,$espa�ol)){
	$text = $smcFunc['htmlspecialchars']
	('
		[center][size=13pt][font=tahoma][b][color=#0489B1][u]Adk Portal 2.1[/u][/color][/b][/font][/size][/center]
		[img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Fundador y desarrollador:[/b]
			 [url=http://www.smfpersonal.net/profiles/lucasruroken-u1.html][b]Juarez, Lucas Javier (Lucas-ruroken)[/b][/url]

		[img]http://www.smfpersonal.net/famfamfam/user_red.png[/img] [b]Administradores del proyecto:[/b]
			[url=http://www.smfpersonal.net/profiles/heracles-u259.html][b]Clavijo, Pablo (^Heracles^)[/b][/url]
			[url=http://www.smfpersonal.net/profiles/enik-u417.html][b]Alfaro Garcia, Marco Antonio (Enik)[/b][/url]

		[img]http://www.smfpersonal.net/famfamfam/group.png[/img] [url=http://www.smfpersonal.net/about.html][b]Nuestro staff[/b][/url]'
	);
}
else{
	$text = $smcFunc['htmlspecialchars']
	('
		[center][size=13pt][font=tahoma][b][color=#0489B1][u]Adk Portal 2.1[/u][/color][/b][/font][/size][/center]
        [img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Founder & Developer:[/b]
             [url=http://www.smfpersonal.net/profiles/lucasruroken-u1.html][b]Juarez, Lucas Javier (Lucas-ruroken)[/b][/url]

        [img]http://www.smfpersonal.net/famfamfam/user_red.png[/img] [b]Project Manager:[/b]
              [url=http://www.smfpersonal.net/profiles/heracles-u259.html][b]Clavijo, Pablo (^Heracles^)[/b][/url]
              [url=http://www.smfpersonal.net/profiles/enik-u417.html][b]Alfaro Garcia, Marco Antonio (Enik)[/b][/url]

        [img]http://www.smfpersonal.net/famfamfam/group.png[/img] [url=http://www.smfpersonal.net/about.html][b]Our staff[/b][/url]'
	);
}

//Add a new news :P
$the_array_info = array(
	'titlepage' => 'text',
	'new' => 'text',
	'autor' => 'text',
	'time' => 'int',
);
$the_array_insert = array(
	'Adk Portal was installed',
	$text,
	'Juarez, Lucas (Lucas-ruroken)',
	time(),
);

$smcFunc['db_insert']('insert',
	'{db_prefix}adk_news',
	//Load The Array Info
	$the_array_info,
	//Insert Now;)
	$the_array_insert,
	array('id')
);

//Hooks Integration
$hooks = array(
	'integrate_actions' => 'Adk_portal_add_index_actions',
	'integrate_admin_areas' => 'Adk_portal_add_admin_areas',
	'integrate_menu_buttons' => 'Adk_portal_add_menu_buttons',
	'integrate_display_buttons' => 'Adk_portal_display_buttons',
);

foreach($hooks AS $hook => $call)
	add_integration_function($hook,$call);

if($direct_install)
	echo'Done... Adk portal was installed correctly. Enjoy it!';
	
	
//
?>