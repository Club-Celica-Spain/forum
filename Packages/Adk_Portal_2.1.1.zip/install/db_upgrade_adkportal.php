<?php
/********************************************************
* Adk Portal                   
* Version: 2.0
* Official support: http://www.smfpersonal.net           
* Founder & Developer: Lucas-ruroken
* Project Manager: ^Heracles^ - Enik
* 2009-2011
* Smf Personal - Home of adkportal
/**********************************************************/

$direct_install = false;

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk portal wasn\'t able to conect to smf');

//CreateTables
$tables = array();

//Anothers $smcFunc;
db_extend('packages');

//Hooks Integration
$hooks = array(
	'integrate_actions' => 'Adk_portal_add_index_actions',
	'integrate_admin_areas' => 'Adk_portal_add_admin_areas',
	'integrate_menu_buttons' => 'Adk_portal_add_menu_buttons',
	'integrate_display_buttons' => 'Adk_portal_display_buttons',
);

foreach($hooks AS $hook => $call)
	add_integration_function($hook,$call);

if($direct_install)
	echo'Done... Adk portal was updated correctly. Enjoy it!';
	
	
//
?>