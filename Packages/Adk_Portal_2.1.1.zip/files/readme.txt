[center][size=13pt][font=tahoma][b][color=#0489B1][u]Adk Portal 2.1.1[/u][/color][/b][/font][/size][/center]
[hr]
[center][url=http://www.smfpersonal.net/][img]http://www.smfpersonal.net/Adkmods/logo.png[/img][/url][/center]
[hr]
        [img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Founder & Developer:[/b]
             [url=http://www.smfpersonal.net/profiles/lucasruroken-u1.html][b]Juarez, Lucas Javier (Lucas-ruroken)[/b][/url]

        [img]http://www.smfpersonal.net/famfamfam/user_red.png[/img] [b]Project Manager:[/b]
              [url=http://www.smfpersonal.net/profiles/heracles-u259.html][b]Clavijo, Pablo (^Heracles^)[/b][/url]
              [url=http://www.smfpersonal.net/profiles/enik-u417.html][b]Alfaro Garcia, Marco Antonio (Enik)[/b][/url]

        [img]http://www.smfpersonal.net/famfamfam/group.png[/img] [url=http://www.smfpersonal.net/about.html][b]Our staff[/b][/url]
        
[hr]

        We hope you enjoy your new portal and find in it everything you need.

        Thank you for choosing!!


        [b]Carefully staff of [url=http://www.smfpersonal.net]SMF Personal[/url].[/b]