<?php
if (!defined('SMF'))
	die('Hacking attempt...');
//Quienes esta en linea usando el SSI.php

	adk_whois();
			


?>