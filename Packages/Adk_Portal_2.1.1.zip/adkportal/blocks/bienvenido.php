<?php
if (!defined('SMF'))
	die('Hacking attempt...');
	
//Mejores el mismo ssi :P

	adk_bienvenidos();

	

?>
