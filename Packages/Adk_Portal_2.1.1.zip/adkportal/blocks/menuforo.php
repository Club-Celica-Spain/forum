<?php
if (!defined('SMF'))
	die('Hacking attempt...');
	

//Menu foro... No leidos usuarios etc

	adk_menuforo();





?>