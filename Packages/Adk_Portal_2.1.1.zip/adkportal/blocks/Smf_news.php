<?php
if (!defined('SMF'))
	die('Hacking attempt...');


	adk_Smf_news();

?>