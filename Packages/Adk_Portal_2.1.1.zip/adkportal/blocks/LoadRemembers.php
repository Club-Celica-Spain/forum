<?php
if (!defined('SMF'))
	die('Hacking attempt...');
	
	notasparacambiar();
	
?>