<?php
if (!defined('SMF'))
	die('Hacking attempt...');
	
//Estadisticas usando otro SSI 

	adk_estadisticas();
	

?>