<?php
if (!defined('SMF'))
	die('Hacking attempt...');
	
//Creemos una nueva funcion propia.... Top Posteadores ;D

	adk_topposter10();




?>
