<?php

if (!defined('SMF'))
	die('Hacking attempt...');
	
	//Menu Personal
	adk_menupersonal();


?>	