<?php
/********************************************************
* Adk Portal                   
* Version: 2.0
* Official support: http://www.smfpersonal.net           
* Founder & Developer: Lucas-ruroken
* Project Manager: ^Heracles^ - Enik
* 2009-2011
* Smf Personal - Home of adkportal
/**********************************************************/


/****************************************************************************
** Here... You need to add the folder of your forum.... 
** For example... If your forum is located in www.yourforum.com/forumsmf
** Use: $forum_dir = 'forumsmf';
** If your forum is located in www.yourforum.com/
** Use $forum_dir = ''; 
** Any question... please go to Smfpersonal.net
** Regards ;)
****************************************************************************/
$forum_dir = 'adkportal';


//Wrong dir?
if (!file_exists($forum_dir . '/index.php'))
	die('Wrong $forum_dir value. Please... modify the $forum_dir value ;).');

//I love SSI :D
require_once($forum_dir.'/SSI.php');

//Load the blocks, $adkportal variables, etc
//adkportalSettings(true);

//Now, Load Adk Portal File
require_once($sourcedir . '/Adkportal.php');

//General and General
global $context;
$context['adk_stand_alone'] = true;

//Load the Adk-Modifications.language.php
//If it doesn't exist... load Adk-Modifications.english.php :D
if(loadLanguage('Adk-Modifications') == false)
	loadLanguage('Adk-Modifications','english');

//:)
if (WIRELESS)
	redirectexit();

//Standalone? YEAH!
//adk_standAloneMode(true);

//Finally.... Load the best portal for smf
Adkportal();

//In the end (Linkin park :P)
obExit(true);


?>