[size=3][color=navy][b]Table Plus BBCodes v1.2[/b][/color][/size]
[hr]

[right][table]
[tr][td][color=navy][b]Compatible With:[/b][/color][/td][td]SMF 1.1.X - SMF 2 Beta & RC1[/td][/tr]
[tr][td][color=navy][b]Created By:[/b][/color][/td][td][url=http://www.simplemachines.org/community/index.php?action=profile;u=192278][b].LORD.[/b][/url][/td][td][/td][/tr]
[tr][td][color=navy][b]Version:[/b][/color][/td][td]1.2[/td][/tr]
[tr][td][color=navy][b]Languajes:[/b][/color][/td][td]All[/td][/tr]
[/table][/right]

This MOD Improves and Adds the 'Table BBCodes Buttons' and adds a best style for tables in posts.

[color=navy][b]Version 1.1:[/b][/color] Adds a best style for tables in posts. Improved the visibility of tables, rows, cols.
[color=navy][b]Version 1.2:[/b][/color] Fix issue with styles and other bbcodes.

[center][table]
[tr]
[td][/td][td][center][b]SMF 1.1.X[/b][/center][/td][td][center][b]SMF 2[/b][/center][/td][td][center][b]Now[/b][/center][/td]
[/tr]
[tr]
[td][center][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/table.gif[/img][/center][/td][td][nobbc][table][/table][/nobbc][/td][td][nobbc][table]
[tr]
[td][/td]
[/tr]
[/table][/nobbc][/td][td][nobbc][table]
[tr]
[td][/td][td][/td]
[/tr]
[/table][/nobbc][/td]
[/tr]
[tr]
[td][center][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/tr.gif[/img][/center][/td][td][nobbc][tr][/tr][/nobbc][/td][td][center]-[/center][/td][td][t[i][/i]r]
[t[i][/i]d][/t[i][/i]d][t[i][/i]d][/t[i][/i]d]
[/t[i][/i]r][/td]
[/tr]
[tr]
[td][center][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/td.gif[/img][/center][/td][td][nobbc][td][/td][/nobbc][/td][td][center]-[/center][/td][td][nobbc][td][/td][/nobbc][/td]
[/tr]
[/table][/center]
