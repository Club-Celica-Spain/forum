This file adds an extra action to your SMF installation '?action=sitemap' that will show a sitemap to your visitors and bots.  It will not show boards to a user that its not supposed to.  So a guest will not see hidden boards.  It also has added support for SMF queryless urls.  A link to the sitemap is placed at the bottom of the page with the SMF Copyright information.

If you have Joomla! or Mambo and are running this with Orstio's Bridge, the sitemap will see that and format your links accordingly, and if you are using SEF urls, it will convert them as well.  It also works with the Pretty Urls mod.

Also included is the option to display an XML sitemap for use with Google Sitemaps.  On any of the sitemap pages, simply click the 'XML' link at the bottom for the XML version.  If you wish to submit your site to Google Sitemaps, you will need to use this link.  Google does not like SEF formatted URLs for the sitemap because it won't show the sitemap in the root directory.  Using the link as provided will.  If your forum is in a subdirectory of your site, say http://www.mysite.com/forum, then you will need to create a .htaccess file, or add to one already in your root directory, that contains the following:
[code]
   RewriteEngine on
   RewriteRule ^sitemap.xml$ /forum/index.php?action=sitemap;xml
[/code]
and replace /forum above with the directory of your SMF installation.  Then you will be able to access the sitemap from http://www.myurl.com/sitemap.xml.

Features of the Sitemap:
 - allow everyone or just admins to see the XML *link* (could save on server load on large forums)
 - set the number of topics to show in the XML sitemap and on the pages of the sitemap
 - on the board display, you can have collapsible child boards, to reduce space
 - Works with SEF url settings
 
Simply install the package to install on the SMF Default Core Theme ONLY.

Manual edits will be required for ALL themes (other than SMF Default Core Theme).

If your theme has its own versions of the language files Modifications.english.php and/or Modifications.english-utf8.php, OR if your using a language other than those supported (listed above) by the mod then you will need to copy the language strings into each custom version of those files.

[b]Useful Links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[color=blue][b][size=12pt][u]Support[/u][/size][/b][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)