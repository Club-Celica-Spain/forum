<?php
/*******************************************************************************
This script will remove any settings added by the Custom Permissions mod.

	Upload this file to the folder your forums are in and access
	it directly, with a URL like the following:
		http://www.yourdomain.tld/forum/uninstall_db.php (or similar.)

*******************************************************************************/
// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

if (isset($modSettings['custom_permissions']))
{
	$custom_permissions = unserialize($modSettings['custom_permissions']);

	if(isset($smcFunc))
	{

		if (!empty($custom_permissions))
		{
			$delete_array = array();
			foreach ($custom_permissions as $custom)
				$delete_array[] = $custom['permission'];

			$smcFunc['db_query']('', '
				DELETE FROM {db_prefix}permissions
				WHERE permission IN ({array_string:delete_list})',
				array(
					'delete_list' => $delete_array,
				)
			);
	
			$smcFunc['db_query']('', '
				DELETE FROM {db_prefix}board_permissions
				WHERE permission IN ({array_string:delete_list})',
				array(
					'delete_list' => $delete_array,
				)
			);
		}

		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}settings
			WHERE variable = {string:row}
			LIMIT 1',
			array(
				'row' => 'custom_permissions',
			)
		);
	}
	else
	{
		if (!empty($custom_permissions))
		{
			$delete_array = array();
			foreach ($custom_permissions as $custom)
				$delete_array[] = $custom['permission'];

			db_query("
				DELETE FROM {$db_prefix}permissions
				WHERE permission IN ('" . implode("', '", $delete_array) . "')", __FILE__, __LINE__);
	
			db_query("
				DELETE FROM {$db_prefix}board_permissions
				WHERE permission IN ('" . implode("', '", $delete_array) . "')", __FILE__, __LINE__);
		}

		db_query("
			DELETE FROM {$db_prefix}settings
			WHERE variable = 'custom_permissions'
			LIMIT 1", __FILE__, __LINE__);
	}
}

if (SMF == 'SSI')
	echo 'The database settings for the Custom Permissions mod have been removed. <br /><br />Don\'t forget to remove this file from the server.';

?>