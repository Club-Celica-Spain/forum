This mod will allow you to create custom permissions. Custom permissions can be used when one is scripting to include or exclude member groups from doing certain actions or viewing certain pages.

Usage:

Permissions are used in conjunction with the allowedTo() function. Which will return either true or false depending on whether the permission is set for that member group or not. As an example, if you create a permission named [i]view_this[/i] then it can be used as such:

[code]
if (allowedTo('view_this'))
	echo 'Yes, you can see this.';
else
	echo 'Nope, say goodbye';
[/code]
